﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmpMgt_WebAPI201.Models;

namespace EmpMgt_WebAPI201.EmployeeData
{
   public interface IEmployeeData
    {

        List<Employee> GetEmployees();

        public Employee GetEmployee(Guid id);
       
        Employee AddEmployee(Employee employee);

        void DeleteEmployee(Employee employee);
    }


}
