﻿
using EmpMgt_WebAPI201.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmpMgt_WebAPI201.EmployeeData
{
    public class SqlEmplyeeData : IEmployeeData
    {
        private EmployeeContext _empcontext;
        public SqlEmplyeeData(EmployeeContext employeeContext)
        {
            _empcontext = employeeContext;
        }
        public Employee AddEmployee(Employee employee)
        {
            employee.Id = Guid.NewGuid();
            _empcontext.Employees.Add(employee);
            _empcontext.SaveChanges();
            return employee;
        }

        public void DeleteEmployee(Employee employee)
        {
                _empcontext.Employees.Remove(employee);
                _empcontext.SaveChanges();
            
        }

        public Employee GetEmployee(Guid id)
        {
            return _empcontext.Employees.SingleOrDefault(x => x.Id == id);
        }

        public List<Employee> GetEmployees()
        {
            return _empcontext.Employees.ToList();

          //  throw new NotImplementedException();
        }
    }
}
