﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace EmpMgt_WebAPI201.Models
{
    public class Employee
    {

        [Key]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(25)]
        public string Name { get; set; }

        [Required]  
        public string Competency { get; set; }
    }
}
