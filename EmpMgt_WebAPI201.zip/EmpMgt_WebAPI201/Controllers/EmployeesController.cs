using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmpMgt_WebAPI201.EmployeeData;
using EmpMgt_WebAPI201.Models;


namespace EmpMgt_WebAPI201.Controllers
{

    [ApiController]
//    [Route("[controller]")]

    public class EmployeesController : ControllerBase
    {

        private IEmployeeData _employeeData;
        public EmployeesController(IEmployeeData employeeData)
        {
            _employeeData = employeeData;
        }

        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetEmployees()
        {
            try
            {
              var emp=  _employeeData.GetEmployees();
                if (emp != null)
                    return Ok(emp);
                else
                    return BadRequest();
            }

            catch (Exception ex)
            { return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetEmployee(Guid id)
        {
          
            try
            {
                if (id == null)
                {
                    return BadRequest();
                }
                else
                {
                    var emp = _employeeData.GetEmployee(id);
                    if (emp != null)
                        return Ok(emp);
                    else
                    {
                        return NotFound();
                    }

                }
            }

            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("api/[controller]")]
        public IActionResult GetEmployee(Employee employee)   //Guid guid)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(400);

                _employeeData.AddEmployee(employee);
                // return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + employee.Id, employee);

                return CreatedAtAction("Get", new { id = employee.Id }, employee);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteEmployee(Guid id)//Guid guid)
        {
            try
            {
                var employee = _employeeData.GetEmployee(id);

                if (employee != null)
                {
                    _employeeData.DeleteEmployee(employee);
                    return Ok();
                }
                else
                    return NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }

        }
        //Remove Items

    }
}
